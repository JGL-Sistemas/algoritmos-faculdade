<!DOCTYPE HTML>
<html>
	<head>
		<title>Sistema Escolar:</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	</head>
	<body>
		<div id="page-wrapper">

			<!-- Header -->
				<div id="header-wrapper">
					<div class="container">
						<div class="row">
							<div class="col-12">

								<header id="header">
									       <img src="images/cadastro.jpg" alt=”some text” width=150 height=85>    
									       <div class="redes" img src="images/redes.png" alt=”some text” width=100 height=80>
									<nav id="nav">
										<a href="index.php" class="current-page-item">Home</a>
										<a href="mostraaluno.php">aluno </a>
										<a href="mostraturma.php">turma </a>
										<a href="mostracurso.php">Curso</a>
										
									</nav>
								</header>

							</div>
						</div>
					</div>
				</div>
				<br></br>
				<div class="col_w360 float_r">
	</body>
</html>
<?php include('conecta.php'); ?>