<?php

$host = 'localhost';
$database = 'trabalho';
$user = 'root';
$password = '';
$con = mysqli_connect($host, $user, $password, $database);

