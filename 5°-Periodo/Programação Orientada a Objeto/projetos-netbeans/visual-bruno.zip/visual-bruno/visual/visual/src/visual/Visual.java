package visual;
public class Visual {
    public static void main(String[] args) {
    conector bd = new conector();
    questionar pQuest = new questionar();
    Principal pessoa = new Principal();
    pessoa.setVisible(true);
    
    
       
    }
    
}
